/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contas_energia;


public class Imovel {
    
 private int codigoregistro;   
 private Contas[] conta ;   
 private int quantidadecontas;
 
 public Imovel(int codigoregistro){
     this.codigoregistro = codigoregistro;
     conta = new Contas [12];
     quantidadecontas = 0;    
 }
 
 public void adicionarContas(Contas contas){
     
     if (quantidadecontas < conta.length){
         conta[quantidadecontas] = contas;
         quantidadecontas++;
     }
     
 }
 
  public int getCodigoregistro() {
return codigoregistro;
}

public void setCodigoregistro(int codigoregistro) {
this.codigoregistro = codigoregistro;
}

  public int getQuantidadecontas() {
return quantidadecontas;
}

public void setQuantidadecontas(int quantidadecontas) {
this.quantidadecontas = quantidadecontas;
}

public void medio12contas(){
    if(quantidadecontas > 0){
    double media = 0.0;
    double soma = 0.0;
    
    for(int i =0; i < quantidadecontas; i++){
         soma = soma + conta[i].getValor_imposto();
    }
    
    media = soma / quantidadecontas;
    
    System.out.println("• O valor medio: "+String.format("%.2f", media)+ 
            " das contas de energia"+
            " pagas nos últimos 12 meses");
    
    }
}

public void contacara(){
    if(quantidadecontas > 0){
    
   double cara =0.0; 
    
       for(int i =0; i < quantidadecontas; i++){
           
        if(conta[i].getValor_imposto()> cara){   
         cara = conta[i].getValor_imposto();
       }
        
    }
   
       System.out.println("O valor da conta mais cara é de :"+String.format("%.2f", cara)+""
               + " do imovel nos últimos 12 meses;");
    }
}

public void resumomedio12acima(){
    
    if(quantidadecontas > 0){
        
    double media = 0.0;
    double soma = 0.0;
    
    for(int i =0; i < quantidadecontas; i++){
         soma = soma + conta[i].getValor_imposto();
    }
    
    media = soma / quantidadecontas;
    
     for(int i =0; i < quantidadecontas; i++){
         
         if(conta[i].getValor_imposto() > media){
             conta[i].Resumoconta();
         }
       }
     }
     System.out.println("\n");
    System.out.println("contas do imovel que tiveram valor acima da media");
}

public void resumoanual(){
    if(quantidadecontas > 0){
    
    System.out.println("resumo anual do imovel"+
                        " de cada conta do ano");
    System.out.println("\n");
    
    for(int i =0; i < quantidadecontas; i++){
        
         System.out.println("o consumo: "+conta[i].getConsumo()+
                  "valor" +String.format("%.2f", conta[i].getValor_imposto()));
         System.out.println("\n");
    }
    }
}

public Contas buscarConta(String mes) {
    if(quantidadecontas > 0){
    for (int i = 0; i < quantidadecontas; i++) {
        
        if (conta[i].getMes_conta().equalsIgnoreCase(mes)) {
            return conta[i]; 
        }
    }
    }
    return null; 
}


}//fim 
