/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contas_energia;

public class Condominios {
     private Imovel[] imovel;
     private int quantidadeimovel;
    
    public Condominios(){
     imovel = new Imovel [10];
     quantidadeimovel = 0;    
 }
     
     public void adicionarImovel(Imovel imoves){
     
     if (quantidadeimovel < imovel.length){
         imovel[quantidadeimovel] = imoves;
         quantidadeimovel++;
     }
 }
    
   public Imovel buscarimovelnumero(int Buscaimovel) {
    for (int i = 0; i < quantidadeimovel; i++) {
       
        if (imovel[i].getCodigoregistro()==(Buscaimovel)) {
            return imovel[i]; 
        }
    }
    return null; 
}  
     
}//fim
