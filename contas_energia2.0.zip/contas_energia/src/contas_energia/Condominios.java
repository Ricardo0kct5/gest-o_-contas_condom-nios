/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contas_energia;

public class Condominios {
     private Imovel[] imovel;
     private int quantidadeimovel;
    
    public Condominios(){
     imovel = new Imovel [10];
     quantidadeimovel = 0;    
 }
     
     public void adicionarImovel(Imovel imoves){
     boolean unico = true;
     verificasao(imoves.getCodigoregistro());
         
      if(unico == false){   
     if (quantidadeimovel < imovel.length){
         imovel[quantidadeimovel] = imoves;
         quantidadeimovel++;
         
         System.out.println(" O Imovel foi Cadastrar");
         System.out.println("\n");
     }
     }
      if(unico == true){
          System.out.println("registro numerico infomado para Cadastrar do imovel ja esta sendo utilizado");
          System.out.println("\n");
      }
      
 }
    
   public Imovel buscarimovelnumero(int Buscaimovel) {
    for (int i = 0; i < quantidadeimovel; i++) {
       
        if (imovel[i].getCodigoregistro()==(Buscaimovel)) {
            return imovel[i]; 
        }
    }
    return null; 
}  
     
   public boolean verificasao(int Buscaduplicado){
    boolean verdadeiro = false;
       
       for (int i = 0; i < quantidadeimovel; i++) {
           
         if (imovel[i].getCodigoregistro()==(Buscaduplicado)) {
             verdadeiro = true;
            return verdadeiro; 
          }
         
        } 
       return verdadeiro ;
    }
  
   
}//fim
