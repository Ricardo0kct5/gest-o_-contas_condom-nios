/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contas_energia;


public class Contas {
    
  private String mes_conta;
  private double leitura_atual;
  private double leitura_anterior;
  private double consumo;
  private double valor;
  private double valor_imposto;
    
  
  public Contas(String mes_conta, double leitura_atual, double leitura_anterior) {
      this.mes_conta = mes_conta;
      this.leitura_atual = leitura_atual;
      this.leitura_anterior = leitura_anterior;
      
      ConsumoKWH();
      Valor();
      ValorImposto();
      
  }
  
  public String getMes_conta() {
return mes_conta;
}

public void setMes_conta(String mes_conta) {
this.mes_conta = mes_conta;
}

public double getLeitura_atual() {
return leitura_atual;
}

public void setLeitura_atual(double leitura_atual) {
this.leitura_atual = leitura_atual;
}

public double getLeitura_anterior() { 
return leitura_anterior;
}

public void setLeitura_anterior(double leitura_anterior) {
this.leitura_anterior = leitura_anterior;
}

public double getConsumo() { 
return consumo;
}

public void setConsumo(double consumo) {
this.consumo = consumo;
}

public double getValor() {
return valor;
}

public void setValor(double valor) {
this.valor = valor;
}

public double getValor_imposto() {
return valor_imposto;
}

public void setValor_imposto(double valor_imposto) {
this.valor_imposto = valor_imposto;
}
  
 public void ConsumoKWH(){
     this.consumo = leitura_atual - leitura_anterior;
 }
  
 public void Valor(){
     this.valor = consumo * 0.92;
 } 
  
 public void ValorImposto(){
     
     if(consumo >= 90){
        double iluminacao;
         double ICMS;
         
         iluminacao = valor * 0.025;
         ICMS = (valor + iluminacao) * 0.22;
         
         this.valor_imposto = valor + iluminacao + ICMS;
     }
     else{
         this.valor_imposto = this.valor;
     }
 }
 
 public static Contas Compararcontas(Contas contas1,Contas contas2){
     
     if(contas1.getValor_imposto() > contas2.getValor_imposto() ){
     return contas1;
 }
 else{
     return contas2;
 }
             
 }
 
 public void Resumoconta(){
     System.out.println(
      "-- Resumo da conta --"+ "\n"+
      "mes: "+ mes_conta+"\n"+
      "consumo: "+consumo+"\n"+
      "valor total: "+String.format("%.2f", valor_imposto));
      
 }
 
 
 
 
}//fim
