/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package contas_energia;

import java.util.Scanner;


public class Contas_energia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Condominios novoimovel = new Condominios();
        
        
        Imovel Imovel2 = new Imovel(150);
        
        Contas jan = new Contas("janeiro", 400.0, 250.0);
        Contas fev = new Contas("fevereiro", 500.0, 400.0);
        Contas mar = new Contas("março", 300.0, 150.0);
        Contas abr = new Contas("abril", 570.0, 352.0); 
        Contas mai = new Contas("maio", 810.0, 510.0);
        Contas jun = new Contas("junho", 902.0, 870.0);
        Contas jul = new Contas("julho", 7040.0, 4340.0);
        Contas ago = new Contas("agosto", 1843.0, 963.0);
        Contas set = new Contas("setembro", 7300.0, 5950.0);
        Contas out = new Contas("outubro", 1500.0, 500.0);
        Contas nov = new Contas("novembro", 1950.0, 856.0);
        Contas dez = new Contas("dezembro", 1483.0, 408.0);
         
        
        Imovel2.adicionarContas(jan);
        Imovel2.adicionarContas(fev);
        Imovel2.adicionarContas(mar);
        Imovel2.adicionarContas(abr);
        Imovel2.adicionarContas(mai);
        Imovel2.adicionarContas(jun);
        Imovel2.adicionarContas(jul);
        Imovel2.adicionarContas(ago);
        Imovel2.adicionarContas(set);
        Imovel2.adicionarContas(out);
        Imovel2.adicionarContas(nov);
        Imovel2.adicionarContas(dez);
        
        novoimovel.adicionarImovel(Imovel2);
        
        int opcao = 0;
        while (opcao != -1) {
            System.out.println(
                    "Escolha uma opcao:\n"
                    + "1-Imovel\n"
                    + "2-Contas\n"
                    +"-1 Sair");
            opcao = ler.nextInt();
        
             switch (opcao) {
                
                case 1:
                    int opcaoImovel = 0;
                    while (opcaoImovel != -1) {
                        System.out.println("Escolha uma opcao:\n"
                                + "1-Cadastrar Imovel\n"
                                + "2-media anual\n" +
                                "3-maio varlo das contas\n"+
                                "4-contas acima media do ano\n"+
                                "5-resumo anual\n"
                        );  
                        System.out.println("-1 Sair");
                        opcaoImovel = ler.nextInt();
                        ler.nextLine();
            
                      switch (opcaoImovel) {
                          case 1:
                           System.out.println("\nInforme o registro numerico do Imovel para Cadastrar:");
                                int registro = ler.nextInt();
                                Imovel imovelN = new Imovel(registro); 
                                novoimovel.adicionarImovel(imovelN);
                                
                                System.out.println("\n");
                              break; 
                          
                          case 2:
                          System.out.println("\nInforme o registro numerico para media anual do Imovel:");
                        int numero = ler.nextInt();
                              
                              
                         Imovel imovelEn = novoimovel.buscarimovelnumero(numero);

                           if (imovelEn != null) {
                            System.out.println("\nImovel encontrado:");
                            imovelEn.medio12contas();
                            System.out.println("\n");
                           }
                         System.out.println("\nImovel nao foi encontrada para media anual do Imovel");
                        System.out.println("\n");
                        
                         break;
                           
                        case 3:
                      System.out.println("Informe o registro numerico do imove para O valor da conta mais cara do imovel:");
                       int numero1 = ler.nextInt();
                              
                       Imovel imovelEnc = novoimovel.buscarimovelnumero(numero1); 
                            
                        if (imovelEnc != null) {
                            System.out.println("\nImovel encontrado:"+"\n");
                            imovelEnc.contacara();
                            System.out.println("\n");
                           }
                            System.out.println("\n Imovel nao foi encontrada para  O valor da conta mais cara do imovel");
                        System.out.println("\n");
                        
                         break;    
                          
                      case 4:
                      System.out.println("\nInforme o registro numerico para mosta as contas do imovel que tiveram valor acima da media:");
                       int numero2 = ler.nextInt();
                              
                       Imovel imovelEnco = novoimovel.buscarimovelnumero(numero2); 
                       
                         
                         
                        if (imovelEnco != null) {
                            System.out.println("\nImovel encontrado:");
                            imovelEnco.resumomedio12acima();
                            System.out.println("\n");
                           }
                        System.out.println("\n Imovel nao foi encontrada para imovel que tiveram valor acima da media");
                        System.out.println("\n");
                        
                         break; 
                         
                      case 5:
                      System.out.println("\nInforme o registro numerico para mosta um resumo das contas nos últimos 12 meses.:");
                       int numero3 = ler.nextInt();
                              
                       Imovel imovelEncon = novoimovel.buscarimovelnumero(numero3); 
                       
                            
                            
                        if (imovelEncon != null) {
                            System.out.println("\nImovel encontrado:");
                            imovelEncon.resumoanual();
                            System.out.println("\n");
                           }
                        System.out.println("\n Imovel nao foi encontrada para resumo dos últimos 12 meses");
                        System.out.println("\n");
                        
                         break;
                         
                      }    
                        
                  }
                  break;  
              case 2:
                    int opcaoContas = 0;
                    while (opcaoContas != -1) {
                        System.out.println(
                                "Escolha uma opcao:\n"
                                + "1-Cadastrar conta\n"
                                + "2-Consultar Conta\n" +
                                "3-Comparar contas\n"
                        ); 
                        System.out.println("-1 Sair");
                        opcaoContas = ler.nextInt();
                        ler.nextLine();
            
                       switch (opcaoContas) {
                           
                       case 1:
                     System.out.println("\nInforme o mes atual para Cadastrar:");
                       String mesatual = ler.nextLine();
                       
                       ler.nextLine();
                      System.out.println("\nInforme o leitura atual do relógio medidor para Cadastrar:");
                       double leituraatual = ler.nextDouble(); 
                       
                       System.out.println("\nInforme leitura anterior  do relógio medidor para Cadastrar:");
                       double leituraanterior = ler.nextDouble();
                       
                       System.out.println("\nInforme o registro numerico do Imovel para Cadastrar a conta:");
                       int numero = ler.nextInt();
                       
                       Imovel imovelEn = novoimovel.buscarimovelnumero(numero);

                       
                        Contas novaco = new Contas(mesatual, leituraatual, leituraanterior); 
                         imovelEn.adicionarContas(novaco);
                         
                         System.out.println(" Conta foi Cadastrar:");
                         System.out.println("\n");
                         
                           break;   
                           
                       case 2:
                           
                       System.out.println("\nInforme o registro numerico do Imovel para Consultar a conta:");
                       int numero2 = ler.nextInt();
                       
                       Imovel imovelEnc = novoimovel.buscarimovelnumero(numero2);   
                           
                       ler.nextLine();
                      System.out.println("\nInforme o nome do mes para Consultar da conta:");
                        String nome = ler.nextLine();
                        
                       Contas contaEnc = imovelEnc.buscarConta(nome); 
                            
                        if (contaEnc != null) {
                            System.out.println("\nConta encontrado:");
                            contaEnc.Resumoconta();
                            System.out.println("\n");
                           }
                         System.out.println("\nConta nao foi encontrada:");
                            System.out.println("\n");
                         break;     
                           
                       case 3:
                           
                       System.out.println("\nInforme o registro numerico do Imovel para Consultar a conta:");
                       int numero3 = ler.nextInt();
                       
                       Imovel imovelEnco = novoimovel.buscarimovelnumero(numero3);   
                        
                       ler.nextLine();
                       
                      System.out.println("\nInforme o nome do mes para comparar a conta:");
                        String nome1 = ler.nextLine();
                        
                       System.out.println("\nInforme o nome do mes para Comparar as conta:");
                        String nome2 = ler.nextLine();
                        
                       Contas contaEnco = imovelEnco.buscarConta(nome1);        
                       Contas contaEncon = imovelEnco.buscarConta(nome2); 
                            
                        if (contaEnco != null && contaEncon != null ) {
                            System.out.println("\nConta encontrado:");
                            Contas resultado = Contas.Compararcontas(contaEnco, contaEncon);
                            
                            System.out.println("\n a conta mais cara entre os dois meses é:");
                            resultado.Resumoconta();
                            System.out.println("\n");
                           }
                            System.out.println("\n uma das Conta nao foi encontrada:");
                            System.out.println("\n");
                         break;   
                             
                       }     
                  }
                       
             }
             
        } 
        
    }
      
}//fim class
